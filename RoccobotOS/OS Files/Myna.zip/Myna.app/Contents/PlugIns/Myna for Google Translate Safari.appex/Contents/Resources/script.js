var translator = null;
activetranslator();

safari.self.addEventListener("message", messageHandler); // Message recieved from Obj code

function gttranslator(){
    "use strict";
    
    var me = {};
    var timerinterval = null;
    var timerintervalCSSMenu = null;
    var bodyObserver = null;
    
    var clickretry = 0;
    var translated = false;
    var domaincounntry = 'com';
    
    
    me.translatePageAlt = function(lang,server){
        clearRemaining();
        clickretry = 0;
        translated = false;
        if(server == 1) domaincounntry = 'cn'; else domaincounntry = 'com';
        
        var sourceLang = 'auto';
        var targetLang = lang;
        me.saveUserDefaults('googtrans','/' + sourceLang +'/'+targetLang);
        monitorBodyNodes();
        if(!document.getElementById("google_translate_element")){
            var body = document.body;
            var gtel = document.createElement("div");
            gtel.id = "google_translate_element";
            body.insertBefore(gtel,body.firstChild);
            
            var gtelscpt1 = document.createElement("script");
            gtelscpt1.id = "gt_scpt1";
            gtelscpt1.innerHTML = "function googleTranslateElementInit(){ new google.translate.TranslateElement({pageLanguage: '"+sourceLang+"',defaultLanguage: '"+targetLang+"',multilanguagePage: true});}";
            body.insertBefore(gtelscpt1,body.firstChild);
            
            var gtelscpt2 = document.createElement("script");
            gtelscpt2.id = "gt_scpt2";
            gtelscpt2.src = "https://translate.google." + domaincounntry + "/translate_a/element.js?cb=googleTranslateElementInit";
            body.insertBefore(gtelscpt2,body.firstChild);
        }
//        timerinterval = setInterval(clickGT,50);
    }
    
    
    function clearRemaining(){
        //we clear the existing nodes if panel was closed. Other wise need to reload before be able to use again.
        clearInterval(timerinterval);
        clearInterval(timerintervalCSSMenu); //should never be needed but we never know.
        var gtbannerframe = document.getElementsByClassName("goog-te-banner-frame");
        if(gtbannerframe && gtbannerframe>0){
            var iframe = gtbannerframe[0].contentDocument;
            if(iframe){
                removeNode(iframe.getElementById('mynaStyleAlt'));
            }
        }
        var gtselectionframe = document.getElementsByClassName("goog-te-menu-frame");
        if(gtselectionframe && gtselectionframe>0){            
            var iselectionframe = gtselectionframe[0].contentDocument;
            if(iselectionframe){
                removeNode(iselectionframe.getElementById('mynaStyleAlt'));
            }
        }
                
        removeNode(document.getElementById('google_translate_element'));
        removeNode(document.getElementById('gt_scpt1'));
        removeNode(document.getElementById('gt_scpt2'));
        removeClassNodes('goog-te-spinner-pos');
        removeClassNodes('goog-te-menu-frame');
        removeClassNodes('skiptranslate');
    }
    
    function removeNode(node){
        if(!node) return;
        if(!node.parentNode) return;
        node.parentNode.removeChild(node);
    }
    
    function removeClassNodes(classname){
        var cl1 = document.getElementsByClassName(classname)
        if(!cl1) return;
        for(var i=0; i<cl1.length; i++){
            removeNode(cl1[i]);
        }
    }
    
    function monitorBodyNodes(){
        if(bodyObserver) return;
        
        var MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
        bodyObserver = new MutationObserver(function(mutations){bodynodesDidChange(mutations);});
        var objectToObserve = document.body;
        bodyObserver.observe(objectToObserve, {attributes:true, subtree:true});
    }
    
    function bodynodesDidChange(mutations){
        var myiframe = document.getElementById(':0.container');
        if(!myiframe) return;
        
        bodyObserver.disconnect();
        bodyObserver = null;
        
        clickGT();
    }
    
    
    function clickGT(){
        if(translated) return;
        clickretry++;
        if(clickretry > 40 && !translated) {clearInterval(timerinterval); return;}
        
        var gtframe = document.getElementsByClassName("goog-te-banner-frame");
        
        if(gtframe && gtframe.length>0){
            var iframe=gtframe[0].contentDocument;
            if(iframe){
                gtframe = iframe.getElementById(":0.confirm");
                if(gtframe){
                    addcss();
                    translated = true;
                    clearInterval(timerinterval);
                    gtframe.click();
                }
            }
        }
    }
    
    function addcss(){
        //clean up the very old style visual, to something cleaner.

        addMainiFramecss();
        timerintervalCSSMenu = setInterval(addMenuiFramecss,150);
        addMainDocumentcss();
    }
    
    function addMainiFramecss(){
        var gtbannerframe = document.getElementsByClassName("goog-te-banner-frame");
        if(!gtbannerframe || gtbannerframe.length == 0) return;
        var iframe = gtbannerframe[0].contentDocument;
        if(!iframe) return;
        
        if(!iframe.getElementById('mynaStyleAlt')){
            var styleTag = iframe.createElement("style");
            styleTag.setAttribute('id','mynaStyleAlt');
            var hidebar = '.goog-te-banner{background-color:white!important;background-image:none!important}.goog-te-button{display:none!important}.goog-te-menu-value{color:#333!important;font-weight:600}.goog-logo-link{transform:scale(0.7);padding-left:0px!important;padding-top:4px!important;}body{-webkit-user-select:none}.goog-te-banner td:nth-child(2),.goog-te-banner td:nth-child(3){display:none}.goog-logo-link img{height:24px}';
            
            
            var svg = '<svg width="58px" height="57px" viewBox="0 0 20 220" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g id="Artboard" transform="translate(-1346.000000, -1568.000000)" fill="#757575" fill-rule="nonzero"><path d="M1378,1594 L1400,1594 L1400,1600 L1378,1600 L1378,1622 L1372,1622 L1372,1600 L1350,1600 L1350,1594 L1372,1594 L1372,1572 L1378,1572 L1378,1594 Z" id="Combined-Shape" transform="translate(1375.000000, 1597.000000) rotate(45.000000) translate(-1375.000000, -1597.000000) "></path></g></g></svg>'
            
            var closebuttonimg = '.goog-close-link img{background-image:url(\'data:image/svg+xml;charset=UTF-8,' + svg + '\')!important;}';
            
            var svg2 = '<svg width="58px" height="58px" viewBox="0 -10 120 300" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g id="Artboard" transform="translate(-1346.000000, -1648.000000)" fill="#757575" fill-rule="nonzero"><polygon id="Triangle" transform="translate(1375.500000, 1678.500000) scale(1, -1) translate(-1375.500000, -1678.500000) " points="1375.5 1661 1399 1696 1352 1696"></polygon></g></g></svg>';
            
            var dropdownimg = '.goog-te-menu-value img{background-image:url(\'data:image/svg+xml;charset=UTF-8,' + svg2 + '\')!important;}';
            
            var darktheme = '@media (prefers-color-scheme: dark) {' + '.goog-te-banner{background-color:rgb(46,47,48)!important}.goog-te-menu-value{color:#ccc!important}.goog-te-banner-content{color:#fff}' + '}';
            
            styleTag.textContent = hidebar + closebuttonimg + dropdownimg + darktheme;
            iframe.documentElement.appendChild(styleTag);
        }
    }
    
    function addMenuiFramecss(){
        //there is manny menu-frame. Difficult to identify the active one. Let's tags them all.
        var gtselectionframe = document.getElementsByClassName("goog-te-menu-frame");
        if(!gtselectionframe) return null;
        
        for(var i=0; i<gtselectionframe.length;i++){
            var iselectionframe = gtselectionframe[i].contentDocument;
            if(!iselectionframe.getElementById('mynaStyleAlt')){
                var styleTag3 = iselectionframe.createElement("style");
                styleTag3.setAttribute('id','mynaStyleAlt');
                var hidebar3 = '.goog-te-menu2-item div{border-radius:4px;color:black!important}.goog-te-menu2-item:hover div{background:#ddd!important;color:black!important}.goog-te-menu2{border:none!important;padding:8px!important}.goog-te-menu2 *{line-height:1.5}';
                var darktheme = '@media (prefers-color-scheme: dark) {' + '.goog-te-menu2,.goog-te-menu2-item div{background-color:rgb(46,47,48)!important}.goog-te-menu2-item div,.goog-te-menu2-item:hover div{color:#fff!important;}.goog-te-menu2-item:hover div{background-color:#555!important}.goog-te-menu2-item-selected div{color:#ddd!important}' + '}';
                
                styleTag3.textContent = hidebar3 + darktheme;
                iselectionframe.documentElement.appendChild(styleTag3);
            }
        }
        
        clearInterval(timerintervalCSSMenu);
    }
        
    
    function addMainDocumentcss(){
        if(!document.getElementById('mynaStyleAlt')){
            var styleTag2 = document.createElement("style");
            styleTag2.setAttribute('id','mynaStyleAlt');
            var hidebar2 = '.goog-te-banner-frame{height:26px!important;border:none!important;box-shadow:0 0 8px 1px rgba(0,0,0,0.5)!important}.goog-te-menu-frame{box-shadow:0 3px 8px 2px rgba(0,0,0,0.5)!important;top:27px!important}#goog-gt-tt{border-color:rgb(66,67,68);color:#ddd!important;background-color:rgb(46,47,48)!important}';
            
            var overlaygtimprove = '#goog-gt-tt{display:none!important}.goog-text-highlight{background-color:transparent!important;box-shadow:none!important}';
            
            
            styleTag2.textContent = hidebar2 + overlaygtimprove;
            document.documentElement.appendChild(styleTag2);
        }
    }
    
    
    me.saveUserDefaults = function (name,value) {
        var date = new Date();
        date.setTime(date.getTime()+(365*10*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
        document.cookie = name+"="+value+expires+";";
    }
    
    me.dealloc = function(){
        bodyObserver.disconnect();
        bodyObserver = null;
        clearRemaining();
    }
    
    return me;
}


function messageHandler(event) {
    if(!translator) return;
    translator.translatePageAlt(event.name,event.message['server']);
}


function activetranslator(){
    if(window.location !== window.parent.location) return;
    
    if(document.getElementById('activemynatranslator')) return;
    var styleTag2 = document.createElement("div");
    styleTag2.setAttribute('id','activemynatranslator');
    document.documentElement.appendChild(styleTag2);
    
    if(!translator)
        translator = new gttranslator();
}
